package eg.edu.guc.santorini.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class GUIGameOver extends JFrame implements ActionListener {
	private GUIBoard g;
	public GUIGameOver(String name, GUIBoard g) {
		super("Game over");
		this.g = g;
		JPanel p = new JPanel();
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(p , BorderLayout.CENTER);
		JLabel l = new JLabel(new ImageIcon("lol/Winner.png"));
		p.add(l);
		JLabel n = new JLabel(name + " Won !!!!!!");
		p.add(n);
		
		JPanel p2 = new JPanel();
		JButton b = new JButton("new game");
		b.addActionListener(this);
		b.setActionCommand("new");
		
		p2.add(b);
		getContentPane().add(p2 , BorderLayout.SOUTH);
		setSize(250, 500);
		setVisible(true);
	}

	//@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("new")) {
			g.dispose();
			dispose();
			new GUIGame();
		}
	}
}
