package eg.edu.guc.santorini.tiles;

public class Tile {

}
