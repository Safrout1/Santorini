package eg.edu.guc.santorini.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import eg.edu.guc.santorini.adapter.Adapter;

//import javax.swing.border.Border;

//@SuppressWarnings("serial")
public class GUIGame extends JFrame implements ActionListener {
	private JButton btn;

	public GUIGame() {
		super("Santorini");

		Container contentPane = getContentPane();
		
		contentPane.setLayout(new BorderLayout());
		
		JPanel x = new JPanel();
		x.setLayout(new FlowLayout());

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		btn = new JButton("New Game");
		btn.setOpaque(true);
		btn.setFont(new Font("New Game", 40, 40));
		btn.setBackground(Color.blue);
		btn.setBorder(BorderFactory.createLineBorder(Color.red));
		btn.setForeground(Color.pink);
		btn.addActionListener(this);
		btn.setActionCommand("Open");
		add(btn , BorderLayout.CENTER);
		pack();

		JLabel y = new JLabel("Santorini");
		y.setFont(new Font("Santorini", 60, 60));
		y.setForeground(Color.blue);
		x.setBackground(Color.red);
		x.add(y, BorderLayout.CENTER);
		contentPane.add(x, BorderLayout.NORTH);


		setVisible(true);
		setSize(1000, 700);

	}

	//@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if (cmd.equals("Open")) {
			dispose();
			GUIPlayer player1 = new GUIPlayer("Player 1", new Adapter());
		}

	}

	public static void main(String[] args) {
		new GUIGame().setVisible(true);
	}
}
