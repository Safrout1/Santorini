package eg.edu.guc.santorini.exceptions;

@SuppressWarnings("serial")
public class InvalidMoveException extends Exception {

	public InvalidMoveException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMoveException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}


